package com.maestros.FlyingBartender.model;

public class CartTittleModel {
    String tittle;

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public CartTittleModel(String tittle) {
        this.tittle = tittle;
    }
}
