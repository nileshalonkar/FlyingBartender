package com.maestros.FlyingBartender.activities;

public interface CheckInterface {
    void checkData(String s,Boolean aBoolean,int pos);
}
