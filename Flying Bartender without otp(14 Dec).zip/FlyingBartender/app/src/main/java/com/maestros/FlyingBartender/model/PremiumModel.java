package com.maestros.FlyingBartender.model;

public class PremiumModel {

  int image;

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public PremiumModel(int image) {
        this.image = image;
    }
}
