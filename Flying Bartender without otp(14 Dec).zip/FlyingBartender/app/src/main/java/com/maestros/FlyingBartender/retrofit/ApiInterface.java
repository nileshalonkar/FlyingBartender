package com.maestros.FlyingBartender.retrofit;

interface ApiInterface {

   /* @GET("/api/unknown")
    Call<MultipleResource> doGetListResources();

    @POST("/api/users")
    Call<User> createUser(@Body User user);*/

}
