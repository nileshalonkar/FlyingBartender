package com.maestros.FlyingBartender.utils;

public class AppConstats {
    public static final String USER_ID = "USER_ID";
    public static final String CATEGORYID = "CATEGORYID";
    public static final String CATEGORYNAME = "CATEGORYNAME";
    public static final String PRODUCTID = "PRODUCTID";
    public static final String BRANDID = "BRANDID";
    public static final String SELLERID = "SELLERID";
    public static final String BRANDNAME = "BRANDNAME";
    public static final String USER_NAME = "USER_NAME";
    public static final String EMAIL_ID = "EMAIL_ID";
    public static final String MOBILE_NUMBER = "MOBILE_NUMBER";
    public static final String USER_AGE = "USER_AGE";
    public static final String USER_TYPE = "USER_TYPE";
    public static final String USER_PASSWORD = "USER_PASSWORD";
    public static final String USER_MOBILE = "USER_MOBILE";
    public static final String SELECTADDRESS = "SELECTADDRESS";
    public static final String SELECTLAT = "SELECTLAT";
    public static final String SELECTLONG = "SELECTLONG";
    public static final String SELECTCITY = "SELECTCITY";
    public static final String SUB_CATEGORYID = "SUB_CATEGORYID";
    public static final String SUB_CATEGORYNAME = "SUB_CATEGORYNAME";


}
