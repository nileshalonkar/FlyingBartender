package com.maestros.FlyingBartender.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.chaos.view.PinView;
import com.maestros.FlyingBartender.R;
import com.maestros.FlyingBartender.retrofit.BaseUrl;
import com.maestros.FlyingBartender.utils.AppConstats;
import com.maestros.FlyingBartender.utils.SharedHelper;

import org.json.JSONObject;

import static com.maestros.FlyingBartender.retrofit.BaseUrl.LOGIN;
import static com.maestros.FlyingBartender.retrofit.BaseUrl.OTPVERIFY;

public class NewOtpVerifyActivity extends AppCompatActivity {
    PinView firstPinView;
    Button btnVerify;
    String user_id = "";
    private String email = "";
    TextView tvMail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_otp_verify);
        firstPinView = findViewById(R.id.firstPinView);
        btnVerify = findViewById(R.id.btnVerify);
        tvMail = findViewById(R.id.tvMail);
        user_id = SharedHelper.getKey(NewOtpVerifyActivity.this, AppConstats.USER_ID);
        Log.e("ssss", user_id);

        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyOtp();

            }
        });

    }

    public void verifyOtp() {
        AndroidNetworking.post(BaseUrl.BASEURL)
                .addBodyParameter("control", OTPVERIFY)
                .addBodyParameter("id", user_id)
                .addBodyParameter("otp", firstPinView.getText().toString().trim())
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("kglfbgkfng", "onResponse: " + response.toString());
                        try {
                            if (response.getString("result").equals("otp match successfully")) {
                                Toast.makeText(NewOtpVerifyActivity.this, "" + response.getString("result"), Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(NewOtpVerifyActivity.this, BottomNavActivity.class));

                            } else {
                                Toast.makeText(NewOtpVerifyActivity.this, "" + response.getString("result"), Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            Log.e("sdjxksmd", "onResponse: " + e.getMessage());


                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("vhgvhjbg", "onError: " + anError);

                    }
                });


    }
}