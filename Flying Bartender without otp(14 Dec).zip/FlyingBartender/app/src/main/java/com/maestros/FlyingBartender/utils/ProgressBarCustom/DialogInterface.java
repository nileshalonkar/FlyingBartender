package com.maestros.FlyingBartender.utils.ProgressBarCustom;

import android.content.Context;

public interface DialogInterface {

    void showDialog(int view, Context context);

    void hideDialog();
}
